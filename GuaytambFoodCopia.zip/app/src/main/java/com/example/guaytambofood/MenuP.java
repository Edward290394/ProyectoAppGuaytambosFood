package com.example.guaytambofood;

import java.util.Date;

public class MenuP {
    public int id ;
    public String sopa ;
    public String platoFuerte ;
    public String bebida ;
    public String entradaOPostre ;
    public Date fecha ;
    public float precio;
    public byte[] fotoSegundo;

    public MenuP(int id, String sopa, String platoFuerte, String bebida, String entradaOPostre, Date fecha, float precio, byte[] fotoSegundo) {
        this.id = id;
        this.sopa = sopa;
        this.platoFuerte = platoFuerte;
        this.bebida = bebida;
        this.entradaOPostre = entradaOPostre;
        this.fecha = fecha;
        this.precio = precio;
        this.fotoSegundo = fotoSegundo;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSopa() {
        return sopa;
    }

    public void setSopa(String sopa) {
        this.sopa = sopa;
    }

    public String getPlatoFuerte() {
        return platoFuerte;
    }

    public void setPlatoFuerte(String platoFuerte) {
        this.platoFuerte = platoFuerte;
    }

    public String getBebida() {
        return bebida;
    }

    public void setBebida(String bebida) {
        this.bebida = bebida;
    }

    public String getEntradaOPostre() {
        return entradaOPostre;
    }

    public void setEntradaOPostre(String entradaOPostre) {
        this.entradaOPostre = entradaOPostre;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public byte[] getFotoSegundo() {
        return fotoSegundo;
    }

    public void setFotoSegundo(byte[] fotoSegundo) {
        this.fotoSegundo = fotoSegundo;
    }


}

package com.example.guaytambofood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class menuprincipal extends AppCompatActivity {
    private Button btnListaMenu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menuprincipal);
        btnListaMenu=findViewById(R.id.btnListaMenu);
        btnListaMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), ListaMenu.class);
                startActivityForResult(intent, 0);
            }
        });
    }
}
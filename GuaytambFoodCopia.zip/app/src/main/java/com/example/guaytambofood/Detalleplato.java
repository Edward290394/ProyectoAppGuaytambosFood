package com.example.guaytambofood;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Detalleplato extends AppCompatActivity {
    private static String URL_CARGAR="http://alexis247-001-site1.btempurl.com/ApiwcfJson.svc/car";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalleplato);
    }
}